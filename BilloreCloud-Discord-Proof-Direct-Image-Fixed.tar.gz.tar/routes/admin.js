var express = require('express');
var multer = require('multer');
var fs = require('fs');
var path = require('path');
var crypto = require('crypto');
var router = express.Router();
var discordService = require('../discord-service');

var dataDir = path.join(__dirname, '..', 'data');
var uploadDir = path.join(__dirname, '..', 'public', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
var storage = multer.diskStorage({
  destination: function(req, file, cb) { cb(null, uploadDir); },
  filename: function(req, file, cb) {
    var ext = path.extname(file.originalname || '').toLowerCase();
    var safeExt = ['.png','.jpg','.jpeg','.webp','.gif'].indexOf(ext) >= 0 ? ext : '.png';
    cb(null, Date.now() + '-' + Math.random().toString(36).slice(2, 9) + safeExt);
  }
});
var imageUpload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: function(req, file, cb) {
    cb(null, /^image\/(png|jpe?g|webp|gif)$/i.test(file.mimetype));
  }
});
function uploadedUrl(file) { return file ? '/uploads/' + file.filename : ''; }
function uploadedDataUri(file) {
  if (!file || !file.path) return '';
  try {
    var mime = file.mimetype || 'image/png';
    var base64 = fs.readFileSync(file.path).toString('base64');
    return 'data:' + mime + ';base64,' + base64;
  } catch (e) {
    return '';
  }
}
function removeUploadedFile(url) {
  if (!url || url.indexOf('/uploads/') !== 0) return;
  var file = path.join(uploadDir, path.basename(url));
  try { if (fs.existsSync(file)) fs.unlinkSync(file); } catch (e) {}
}
var adminDataFile = path.join(dataDir, 'admin-data.json');
var usersFile = path.join(dataDir, 'users.json');
fs.mkdirSync(dataDir, { recursive: true });

var defaultData = {
  settings: { site_name: 'BilloreCloud', site_logo: 'https://i.imgur.com/oWNdFZV.png', upi_qr: '', discord_url: '', panel_url: '', panel_api_key: '', panel_type: 'pterodactyl', background_image: '', discord_msg_account: '🎉 Welcome to {{site_name}}!\n\nYour client account has been created successfully.\nEmail: {{email}}\n\nYou can now login and purchase hosting products.', discord_msg_payment: '💳 {{site_name}} payment proof submitted\n\nOrder ID: {{order_id}}\nProduct: {{product}}\nAmount: ₹{{amount}}\nStatus: Payment Review\n\nYour payment proof has been received and is now under review.', discord_msg_complete: '✅ {{site_name}} order completed\n\nOrder ID: {{order_id}}\nProduct: {{product}}\nAmount: ₹{{amount}}\nStatus: Completed\n\nYour order has been completed successfully.', discord_msg_reject: '❌ {{site_name}} order rejected\n\nOrder ID: {{order_id}}\nProduct: {{product}}\nAmount: ₹{{amount}}\nStatus: Rejected\n\nYour payment proof/order was rejected by our team. Please contact support if you need help.' },
  categories: [],
  products: [],
  orders: [],
  invoices: [],
  services: [],
  tickets: []
};

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) { return fallback; }
}
function writeJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}
function getData() {
  var data = readJson(adminDataFile, defaultData);
  data.settings = Object.assign({}, defaultData.settings, data.settings || {});
  if (data.settings.background_image === undefined) data.settings.background_image = '';
  data.categories = Array.isArray(data.categories) ? data.categories : [];
  data.products = Array.isArray(data.products) ? data.products.map(normalizeProduct) : [];
  data.orders = Array.isArray(data.orders) ? data.orders : [];
  data.invoices = Array.isArray(data.invoices) ? data.invoices : [];
  data.services = Array.isArray(data.services) ? data.services : [];
  data.tickets = Array.isArray(data.tickets) ? data.tickets : [];
  writeJson(adminDataFile, data);
  return data;
}
function saveData(data) { writeJson(adminDataFile, data); }
function getUsers() { return readJson(usersFile, []); }

async function sendDiscordDM(userId, content, options) { return discordService.sendDM(userId, content, options); }

function makeId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
function productConfigFromBody(body, existing) {
  var old = existing || {};
  var names = ['cpu','ram','storage','databases','backups','ports','bandwidth'];
  var config = {};
  names.forEach(function(name) {
    config[name] = {
      enabled: body['config_' + name + '_enabled'] === '1' ? true : false,
      value: String(body['config_' + name] || (old[name] && old[name].value) || '').trim()
    };
  });
  return config;
}
function normalizeProduct(p) {
  p.config = p.config || {};
  ['cpu','ram','storage','databases','backups','ports','bandwidth'].forEach(function(name){
    if (!p.config[name]) p.config[name] = {enabled:false,value:''};
    else if (typeof p.config[name] !== 'object') p.config[name] = {enabled:true,value:String(p.config[name])};
  });
  if (p.description_enabled === undefined) p.description_enabled = true;
  if (p.config_enabled === undefined) p.config_enabled = true;
  return p;
}

if (!fs.existsSync(adminDataFile)) writeJson(adminDataFile, defaultData);

function requireAdmin(req, res, next) {
  if (!req.session.admin) return res.redirect('/admin/login');
  next();
}

router.get('/login', function(req, res) {
  if (req.session.admin) return res.redirect('/admin');
  res.render('admin_login', { page: 'Admin Login', error: null });
});

// Admin credentials are stored directly in .env (ADMIN_EMAIL / ADMIN_PASSWORD).
router.post('/login', function(req, res) {
  var email = String(req.body.email || '').trim().toLowerCase();
  var password = String(req.body.password || '');
  var adminEmail = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  var adminPassword = String(process.env.ADMIN_PASSWORD || '');

  if (!adminEmail || !adminPassword) {
    return res.status(500).render('admin_login', {
      page: 'Admin Login',
      error: 'Admin credentials are not configured. Add ADMIN_EMAIL and ADMIN_PASSWORD to .env.'
    });
  }
  if (email !== adminEmail || password !== adminPassword) {
    return res.status(401).render('admin_login', { page: 'Admin Login', error: 'Invalid admin email or password.' });
  }

  req.session.admin = { email: adminEmail, name: 'Administrator' };
  res.redirect('/admin');
});

router.post('/logout', function(req, res) {
  req.session.destroy(function() { res.redirect('/admin/login'); });
});

function dashboardData() {
  var data = getData();
  var users = getUsers();
  var categories = data.categories;
  var products = data.products;
  products.forEach(function(p) {
    var c = categories.find(function(cat) { return String(cat.id) === String(p.category_id); });
    p.category_name = c ? c.name : null;
  });
  return {
    stats: {
      users: users.length,
      orders: data.orders.length,
      invoices: data.invoices.length,
      services: data.services.length,
      tickets: data.tickets.length,
      categories: categories.length,
      products: products.length
    },
    users: users,
    categories: categories,
    products: products,
    orders: data.orders,
    tickets: data.tickets,
    settings: data.settings,
    connected: true,
    error: null
  };
}

router.get('/', requireAdmin, function(req, res) {
  var data = dashboardData();
  res.render('admin', Object.assign({ page: 'Admin Dashboard', admin: req.session.admin, queryReset: String(req.query.reset || ''), panelTest: String(req.query.panelTest || '') }, data));
});

router.post('/settings', requireAdmin, imageUpload.fields([{ name: 'upi_qr', maxCount: 1 }, { name: 'background_image', maxCount: 1 }]), function(req, res) {
  var data = getData();
  data.settings.site_name = String(req.body.site_name || 'BilloreCloud').trim() || 'BilloreCloud';
  data.settings.site_logo = String(req.body.site_logo || '').trim() || 'https://i.imgur.com/oWNdFZV.png';
  data.settings.discord_url = String(req.body.discord_url || '').trim();
  if (req.body.discord_msg_account !== undefined) data.settings.discord_msg_account = String(req.body.discord_msg_account || '').trim();
  if (req.body.discord_msg_payment !== undefined) data.settings.discord_msg_payment = String(req.body.discord_msg_payment || '').trim();
  if (req.body.discord_msg_complete !== undefined) data.settings.discord_msg_complete = String(req.body.discord_msg_complete || '').trim();
  if (req.body.discord_msg_reject !== undefined) data.settings.discord_msg_reject = String(req.body.discord_msg_reject || '').trim();
  data.settings.panel_url = String(req.body.panel_url || '').trim().replace(/\/$/, '');
  data.settings.panel_type = String(req.body.panel_type || 'pterodactyl').trim();
  if (req.body.panel_api_key !== undefined) {
    var newPanelKey = String(req.body.panel_api_key || '').trim();
    if (newPanelKey) data.settings.panel_api_key = newPanelKey;
  }
  if (req.body.clear_panel_key === '1') data.settings.panel_api_key = '';
  var files = req.files || {};
  if (files.upi_qr && files.upi_qr[0]) { removeUploadedFile(data.settings.upi_qr); data.settings.upi_qr = uploadedUrl(files.upi_qr[0]); }
  if (files.background_image && files.background_image[0]) {
    var bgFile = files.background_image[0];
    var bgData = uploadedDataUri(bgFile);
    if (bgData) data.settings.background_image = bgData;
    try { if (bgFile.path && fs.existsSync(bgFile.path)) fs.unlinkSync(bgFile.path); } catch (e) {}
  }
  saveData(data);
  res.redirect('/admin?ok=settings#settings');
});

router.post('/orders/status', requireAdmin, async function(req,res){
  var data=getData(); var id=String(req.body.id||''); var status=String(req.body.status||'');
  var allowed=['payment_review','paid','completed','rejected','cancelled','awaiting_payment'];
  var order=data.orders.find(function(o){return String(o.id)===id;});
  if(order && allowed.indexOf(status)>=0){
    order.status=status;
    if(status==='paid') order.payment_status='paid';
    else if(status==='rejected') order.payment_status='rejected';
    else if(status==='completed') order.payment_status='paid';
    order.updated_at=new Date().toISOString();
    saveData(data);
    if(status==='completed' || status==='rejected') {
      var client = getUsers().find(function(u){ return String(u.id)===String(order.user_id); });
      var discordId = client && client.discord_id ? client.discord_id : '';
      var isRejected = status === 'rejected';
      var fallback = isRejected ? '❌ {{site_name}} order rejected\n\nOrder ID: {{order_id}}\nProduct: {{product}}\nAmount: ₹{{amount}}\nStatus: Rejected\n\nYour payment proof/order was rejected by our team. Please contact support if you need help.' : '✅ {{site_name}} order completed\n\nOrder ID: {{order_id}}\nProduct: {{product}}\nAmount: ₹{{amount}}\nStatus: Completed\n\nYour order has been completed successfully.';
      var template = String(isRejected ? (data.settings.discord_msg_reject || fallback) : (data.settings.discord_msg_complete || fallback));
      var msg = template.split('{{site_name}}').join(String(data.settings.site_name || 'BilloreCloud')).split('{{name}}').join(String(client && client.name || '')).split('{{email}}').join(String(client && client.email || '')).split('{{order_id}}').join(String(order.id)).split('{{product}}').join(String(order.product_name)).split('{{amount}}').join(Number(order.price || 0).toFixed(2)).split('{{status}}').join(isRejected ? 'Rejected' : 'Completed');
      var dm = await sendDiscordDM(discordId, msg, {title:isRejected?'❌ Order Rejected':'✅ Order Completed', color:isRejected?0xED4245:0x57F287, thumbnail:data.settings.site_logo, footer:data.settings.site_name || 'BilloreCloud'});
      if (!dm.sent) console.warn('[Discord] Status DM not sent:', dm.reason, dm.status || '', dm.error || '');
      if (status === 'completed') {
        var completeNotice = await discordService.postCompleteOrder(order, data.settings || {});
        if (!completeNotice.sent) console.warn('[Discord] Complete order server message not sent:', completeNotice.reason || completeNotice.status);
      }
      if (status === 'rejected' && order.discord_new_order_channel_id && order.discord_new_order_message_id) {
        await discordService.editChannelMessage(order.discord_new_order_channel_id, order.discord_new_order_message_id, {components:[]});
      }
    }
  }
  res.redirect('/admin#orders');
});

router.post('/clients/reset-password', requireAdmin, function(req,res){
  var users=getUsers(); var id=String(req.body.id||''); var user=users.find(function(u){return String(u.id)===id;});
  if(!user) return res.redirect('/admin#clients');
  var temp=crypto.randomBytes(6).toString('base64url'); var salt=crypto.randomBytes(16).toString('hex');
  user.password=salt+':'+crypto.scryptSync(temp,salt,64).toString('hex');
  fs.writeFileSync(usersFile,JSON.stringify(users,null,2));
  res.redirect('/admin?reset=' + encodeURIComponent(temp) + '#clients');
});


router.get('/panel/test', requireAdmin, async function(req, res) {
  var data = getData();
  var base = String(data.settings.panel_url || '').replace(/\/$/, '');
  var key = String(data.settings.panel_api_key || '');
  if (!base) return res.redirect('/admin?panelTest=missing#settings');
  if (!key) return res.redirect('/admin?panelTest=nokey#settings');
  try {
    var target = base + '/api/application/nodes?page=1';
    var fetchFn = global.fetch;
    if (typeof fetchFn !== 'function') throw new Error('Fetch is unavailable in this Node.js version.');
    var r = await fetchFn(target, { headers: { 'Authorization': 'Bearer ' + key, 'Accept': 'Application/vnd.pterodactyl.v1+json' } });
    if (r.ok) return res.redirect('/admin?panelTest=ok#settings');
    return res.redirect('/admin?panelTest=bad#settings');
  } catch (e) {
    return res.redirect('/admin?panelTest=error#settings');
  }
});

router.post('/categories/add', requireAdmin, imageUpload.single('image'), function(req, res) {
  var name = String(req.body.name || '').trim();
  var description = String(req.body.description || '').trim();
  if (name) {
    var data = getData();
    data.categories.push({ id: makeId(), name: name, description: description, image: uploadedUrl(req.file), created_at: new Date().toISOString() });
    saveData(data);
  }
  res.redirect('/admin#categories');
});

router.post('/categories/edit', requireAdmin, imageUpload.single('image'), function(req, res) {
  var data = getData();
  var id = String(req.body.id || '');
  var category = data.categories.find(function(c){ return String(c.id) === id; });
  if (category) {
    category.name = String(req.body.name || '').trim() || category.name;
    category.description = String(req.body.description || '').trim();
    if (req.file) { removeUploadedFile(category.image); category.image = uploadedUrl(req.file); }
    category.updated_at = new Date().toISOString();
    saveData(data);
  }
  res.redirect('/admin#categories');
});

router.post('/categories/delete', requireAdmin, function(req, res) {
  var data = getData();
  var id = String(req.body.id || '');
  var category = data.categories.find(function(c) { return String(c.id) === id; });
  if (category) removeUploadedFile(category.image);
  data.categories = data.categories.filter(function(c) { return String(c.id) !== id; });
  data.products.forEach(function(p) { if (String(p.category_id) === id) p.category_id = null; });
  saveData(data);
  res.redirect('/admin#categories');
});

router.post('/products/add', requireAdmin, imageUpload.single('image'), function(req, res) {
  var name = String(req.body.name || '').trim();
  if (name) {
    var data = getData();
    var price = parseFloat(req.body.price || '0');
    data.products.push(normalizeProduct({
      id: makeId(),
      name: name,
      description: String(req.body.description || '').trim(),
      description_enabled: req.body.description_enabled === '1',
      config_enabled: req.body.config_enabled === '1',
      config: productConfigFromBody(req.body),
      category_id: String(req.body.category_id || '').trim() || null,
      type: String(req.body.type || 'hosting').trim(),
      price: isFinite(price) ? price : 0,
      image: uploadedUrl(req.file),
      active: true,
      created_at: new Date().toISOString()
    }));
    saveData(data);
  }
  res.redirect('/admin#products');
});

router.post('/products/edit', requireAdmin, imageUpload.single('image'), function(req, res) {
  var data = getData();
  var id = String(req.body.id || '');
  var product = data.products.find(function(p){ return String(p.id) === id; });
  if (product) {
    normalizeProduct(product);
    product.name = String(req.body.name || '').trim() || product.name;
    product.description = String(req.body.description || '').trim();
    product.description_enabled = req.body.description_enabled === '1';
    product.config_enabled = req.body.config_enabled === '1';
    product.config = productConfigFromBody(req.body, product.config);
    product.category_id = String(req.body.category_id || '').trim() || null;
    product.type = String(req.body.type || product.type || 'hosting').trim();
    var price = parseFloat(req.body.price || '0'); product.price = isFinite(price) ? price : 0;
    if (req.file) { removeUploadedFile(product.image); product.image = uploadedUrl(req.file); }
    product.updated_at = new Date().toISOString();
    saveData(data);
  }
  res.redirect('/admin#products');
});

router.post('/products/toggle', requireAdmin, function(req, res) {
  var data = getData();
  var id = String(req.body.id || '');
  var product = data.products.find(function(p) { return String(p.id) === id; });
  if (product) product.active = !product.active;
  saveData(data);
  res.redirect('/admin#products');
});

router.post('/products/delete', requireAdmin, function(req, res) {
  var data = getData();
  var id = String(req.body.id || '');
  var product = data.products.find(function(p) { return String(p.id) === id; });
  if (product) removeUploadedFile(product.image);
  data.products = data.products.filter(function(p) { return String(p.id) !== id; });
  saveData(data);
  res.redirect('/admin#products');
});

router.post('/tickets/status', requireAdmin, function(req,res) {
  var data = getData();
  var id = String(req.body.id || '');
  var status = String(req.body.status || '');
  var allowed = ['open','in_progress','resolved','closed'];
  var ticket = data.tickets.find(function(t){ return String(t.id) === id; });
  if (ticket && allowed.indexOf(status) >= 0) {
    ticket.status = status;
    ticket.updated_at = new Date().toISOString();
    saveData(data);
  }
  res.redirect('/admin#tickets');
});

router.post('/tickets/reply', requireAdmin, function(req,res) {
  var data = getData();
  var id = String(req.body.id || '');
  var message = String(req.body.message || '').trim();
  var ticket = data.tickets.find(function(t){ return String(t.id) === id; });
  if (ticket && message) {
    ticket.replies = Array.isArray(ticket.replies) ? ticket.replies : [];
    ticket.replies.push({ by:'admin', message:message, created_at:new Date().toISOString() });
    ticket.status = 'in_progress';
    ticket.updated_at = new Date().toISOString();
    saveData(data);
  }
  res.redirect('/admin#tickets');
});

module.exports = router;
