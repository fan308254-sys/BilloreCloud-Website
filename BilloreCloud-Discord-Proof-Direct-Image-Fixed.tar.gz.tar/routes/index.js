var express = require('express');
var crypto = require('crypto');
var fs = require('fs');
var path = require('path');
var router = express.Router();
var multer = require('multer');
var discordService = require('../discord-service');
var uploadDir = path.join(__dirname, '..', 'public', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
var paymentUpload = multer({
  dest: uploadDir,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: function(req, file, cb) { cb(null, /^image\/(png|jpe?g|webp)$/i.test(file.mimetype)); }
});
var usersFile = path.join(__dirname, '..', 'data', 'users.json');
fs.mkdirSync(path.dirname(usersFile), { recursive: true });
if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');

function users() { return JSON.parse(fs.readFileSync(usersFile, 'utf8')); }
function saveUsers(list) { fs.writeFileSync(usersFile, JSON.stringify(list, null, 2)); }
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}
function makePassword(password) {
  var salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + hashPassword(password, salt);
}
function checkPassword(password, stored) {
  var parts = stored.split(':');
  if (parts.length !== 2) return false;
  var actual = hashPassword(password, parts[0]);
  return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(parts[1], 'hex'));
}

async function sendDiscordDM(userId, content, options) { return discordService.sendDM(userId, content, options); }

function discordMessageTemplate(template, vars) {
  var text = String(template || '');
  Object.keys(vars || {}).forEach(function(key){
    text = text.split('{{' + key + '}}').join(String(vars[key] == null ? '' : vars[key]));
  });
  return text;
}

function requireLogin(req, res, next) {
  if (!req.session.user) return res.redirect('/login?next=/panel');
  next();
}

function ticketsData() {
  var file = path.join(__dirname, '..', 'data', 'admin-data.json');
  try {
    var data = JSON.parse(fs.readFileSync(file, 'utf8'));
    data.tickets = Array.isArray(data.tickets) ? data.tickets : [];
    return data.tickets;
  } catch (e) { return []; }
}

function saveTickets(list) {
  var file = path.join(__dirname, '..', 'data', 'admin-data.json');
  var data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) { data = {}; }
  data.tickets = list;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function catalogData() {
  var file = path.join(__dirname, '..', 'data', 'admin-data.json');
  var fallback = { categories: [], products: [] };
  try {
    var data = JSON.parse(fs.readFileSync(file, 'utf8'));
    var categories = Array.isArray(data.categories) ? data.categories : [];
    var products = Array.isArray(data.products) ? data.products : [];

    // Normalize legacy category records so links created by older versions
    // continue to work after the catalog/admin updates.
    categories = categories.map(function(c) {
      var copy = Object.assign({}, c);
      if (copy.id === undefined || copy.id === null || String(copy.id).trim() === '') {
        copy.id = copy._id || copy.category_id || copy.slug || '';
      }
      return copy;
    });

    var activeProducts = products.filter(function(p) { return p.active !== false; }).map(function(p) {
      var cat = categories.find(function(c) {
        return String(c.id) === String(p.category_id) ||
               String(c._id || '') === String(p.category_id) ||
               String(c.slug || '') === String(p.category_id);
      });
      return Object.assign({}, p, { category_name: cat ? cat.name : 'General' });
    });
    return { categories: categories, products: activeProducts };
  } catch (e) { return fallback; }
}

function categoryMatches(category, requestedId) {
  var id = String(requestedId || '').trim();
  if (!id) return false;
  return [category.id, category._id, category.category_id, category.slug]
    .filter(function(v) { return v !== undefined && v !== null; })
    .some(function(v) { return String(v).trim() === id; });
}

/* Home and hosting plans */
router.get('/', function(req, res) { var catalog = catalogData(); res.render('index', {page:'Home', menuId:'home', categories: catalog.categories, products: catalog.products}); });
router.get('/minecraft_free', function(req,res){ res.render('minecraft_free',{page:'MC Free Plans',menuId:'minecraft_free'}); });
router.get('/minecraft_intel', function(req,res){ res.render('minecraft_intel',{page:'MC Intel Plans',menuId:'minecraft_intel'}); });
router.get('/minecraft_amd', function(req,res){ res.render('minecraft_amd',{page:'MC Amd Plans',menuId:'minecraft_amd'}); });
router.get('/vps_free', function(req,res){ res.render('vps_free',{page:'VPS Free Plans',menuId:'vps_free'}); });
router.get('/vps_intel', function(req,res){ res.render('vps_intel',{page:'VPS Intel Plans',menuId:'vps_intel'}); });
router.get('/vps_amd', function(req,res){ res.render('vps_amd',{page:'VPS Amd Plans',menuId:'vps_amd'}); });

/* RDP hosting restored */
router.get('/rdp', function(req,res){ res.render('rdp',{page:'RDP Hosting',menuId:'rdp'}); });

/* Auth */
router.get('/register', function(req,res){
  if (req.session.user) return res.redirect('/');
  res.render('register',{page:'Create Account',menuId:'register',error:null,form:{name:'',email:'',discord_id:''}});
});
router.post('/register', async function(req,res){
  var name = String(req.body.name || '').trim();
  var email = String(req.body.email || '').trim().toLowerCase();
  var password = String(req.body.password || '');
  var discordId = String(req.body.discord_id || '').trim();
  var form = {name:name,email:email,discord_id:discordId};
  if (!name || !email || password.length < 6)
    return res.status(400).render('register',{page:'Create Account',menuId:'register',error:'Name, valid email and a password of at least 6 characters are required.',form:form});
  if (!/^\d{17,20}$/.test(discordId))
    return res.status(400).render('register',{page:'Create Account',menuId:'register',error:'Please enter a valid Discord User ID (17–20 digits). Discord User ID is required for account notifications.',form:form});
  var list = users();
  if (list.some(u => u.email === email))
    return res.status(409).render('register',{page:'Create Account',menuId:'register',error:'An account with this email already exists. Please login.',form:form});
  var user = { id: crypto.randomUUID(), name:name, email:email, password:makePassword(password), discord_id:discordId, createdAt:new Date().toISOString() };
  list.push(user); saveUsers(list);
  req.session.user = { id:user.id, name:user.name, email:user.email, discord_id:user.discord_id };

  var settingsFile = path.join(__dirname, '..', 'data', 'admin-data.json');
  var data = {};
  try { data = JSON.parse(fs.readFileSync(settingsFile, 'utf8')); } catch(e) {}
  var settings = data.settings || {};
  var message = discordMessageTemplate(settings.discord_msg_account || '🎉 Welcome to {{site_name}}!\n\nYour BilloreCloud account has been created successfully.\nEmail: {{email}}\n\nYou can now login and purchase hosting products.', {
    site_name: settings.site_name || 'BilloreCloud', name:name, email:email
  });
  var dm = await sendDiscordDM(discordId, message, {title:'🎉 Account Created', color:0x57F287, thumbnail:settings.site_logo, footer:settings.site_name || 'BilloreCloud'});
  if (!dm.sent) console.warn('[Discord] Account creation DM not sent:', dm.reason, dm.status || '', dm.error || '');
  res.redirect('/');
});
router.get('/login', function(req,res){
  if (req.session.user) return res.redirect('/');
  res.render('login',{page:'Login',menuId:'login',error:null,next:String(req.query.next || '/panel')});
});
router.post('/login', function(req,res){
  var email = String(req.body.email || '').trim().toLowerCase();
  var password = String(req.body.password || '');
  var next = String(req.body.next || '/panel');
  if (!next.startsWith('/') || next.startsWith('//')) next = '/panel';
  var user = users().find(u => u.email === email);
  if (!user || !checkPassword(password,user.password))
    return res.status(401).render('login',{page:'Login',menuId:'login',error:'Incorrect email or password.',next:next});
  req.session.user = { id:user.id, name:user.name, email:user.email, discord_id:user.discord_id || '' };
  res.redirect('/');
});

/* Account settings */
router.get('/account', requireLogin, function(req,res){
  var accountUser = users().find(function(u){ return String(u.id)===String(req.session.user.id); }) || req.session.user;
  res.render('account', {page:'Account Settings', menuId:'account', user:Object.assign({}, req.session.user, {discord_id:accountUser.discord_id || ''}), error:null, success:null});
});
router.post('/account/email', requireLogin, function(req,res){
  var email = String(req.body.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).render('account',{page:'Account Settings',menuId:'account',user:req.session.user,error:'Please enter a valid email address.',success:null});
  var list = users();
  var existing = list.find(function(u){ return u.email === email && u.id !== req.session.user.id; });
  if(existing) return res.status(409).render('account',{page:'Account Settings',menuId:'account',user:req.session.user,error:'That email address is already in use.',success:null});
  var user = list.find(function(u){ return u.id === req.session.user.id; });
  if(!user) return res.redirect('/login');
  user.email = email; saveUsers(list);
  req.session.user.email = email;
  res.render('account',{page:'Account Settings',menuId:'account',user:req.session.user,error:null,success:'Email address updated successfully.'});
});
router.post('/account/password', requireLogin, function(req,res){
  var current = String(req.body.current_password || '');
  var next = String(req.body.new_password || '');
  var confirm = String(req.body.confirm_password || '');
  var list = users(), user = list.find(function(u){ return u.id === req.session.user.id; });
  if(!user || !checkPassword(current,user.password))
    return res.status(400).render('account',{page:'Account Settings',menuId:'account',user:req.session.user,error:'Current password is incorrect.',success:null});
  if(next.length < 6)
    return res.status(400).render('account',{page:'Account Settings',menuId:'account',user:req.session.user,error:'New password must be at least 6 characters.',success:null});
  if(next !== confirm)
    return res.status(400).render('account',{page:'Account Settings',menuId:'account',user:req.session.user,error:'New passwords do not match.',success:null});
  user.password = makePassword(next); saveUsers(list);
  res.render('account',{page:'Account Settings',menuId:'account',user:req.session.user,error:null,success:'Password updated successfully.'});
});

router.post('/account/discord', requireLogin, function(req,res){
  var discordId = String(req.body.discord_id || '').trim();
  if (discordId && !/^\d{17,20}$/.test(discordId)) {
    return res.status(400).render('account',{page:'Account Settings',menuId:'account',user:Object.assign({},req.session.user,{discord_id:discordId}),error:'Please enter a valid Discord User ID (17–20 digits).',success:null});
  }
  var list = users();
  var user = list.find(function(u){ return String(u.id)===String(req.session.user.id); });
  if(!user) return res.redirect('/login');
  user.discord_id = discordId;
  saveUsers(list);
  req.session.user.discord_id = discordId;
  res.render('account',{page:'Account Settings',menuId:'account',user:Object.assign({},req.session.user),error:null,success:discordId?'Discord User ID linked successfully.':'Discord User ID removed.'});
});

router.post('/logout', function(req,res){
  req.session.destroy(function(){ res.redirect('/'); });
});

/* Client panel: only available after account creation/login */
router.get('/panel', requireLogin, function(req,res){
  var catalog = catalogData();
  var file = path.join(__dirname, '..', 'data', 'admin-data.json');
  var data = {}; try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) {}
  var orders = Array.isArray(data.orders) ? data.orders.filter(function(o){ return o.user_id === req.session.user.id; }) : [];
  res.render('panel',{page:'Client Panel',menuId:'panel',user:req.session.user,categories:catalog.categories,orders:orders});
});

router.get('/buy', requireLogin, function(req,res){
  var catalog = catalogData();
  res.render('buy',{page:'Buy Products',menuId:'buy',categories:catalog.categories,products:catalog.products});
});


/* Dynamic catalog: clients choose a category first, then see its products. */
router.get('/category/:id', function(req, res) {
  var catalog = catalogData();
  var requestedId = '';
  try { requestedId = decodeURIComponent(String(req.params.id || '')); } catch (e) { requestedId = String(req.params.id || ''); }
  requestedId = requestedId.trim();

  var category = catalog.categories.find(function(c) { return categoryMatches(c, requestedId); });
  if (!category) {
    return res.status(404).render('error', {
      status: 404,
      message: 'Category not found',
      page: 'Category Not Found'
    });
  }

  var canonicalId = String(category.id || category._id || category.category_id || category.slug);
  var products = catalog.products.filter(function(p) {
    var productCategory = String(p.category_id || p.categoryId || p.category || '').trim();
    return p.active !== false && (productCategory === canonicalId || productCategory === requestedId);
  });

  res.render('category', {
    page: category.name,
    menuId: 'catalog',
    category: category,
    products: products
  });
});

router.get('/product/:id', function(req, res) {
  var catalog = catalogData();
  var product = catalog.products.find(function(p) { return String(p.id) === String(req.params.id) && p.active !== false; });
  if (!product) return res.status(404).render('error', {status:404, message:'Product not found'});
  res.render('product', {page: product.name, menuId:'catalog', product:product, user:req.session.user || null});
});

router.post('/product/:id/buy', requireLogin, function(req, res) {
  var catalog = catalogData();
  var product = catalog.products.find(function(p) { return String(p.id) === String(req.params.id) && p.active !== false; });
  if (!product) return res.status(404).render('error', {status:404, message:'Product not found'});
  var adminFile = path.join(__dirname, '..', 'data', 'admin-data.json');
  var data;
  try { data = JSON.parse(fs.readFileSync(adminFile, 'utf8')); } catch(e) { data = {categories:[],products:[],orders:[],invoices:[],services:[],settings:{}}; }
  data.orders = Array.isArray(data.orders) ? data.orders : [];
  var order = {
    id: crypto.randomUUID(), user_id: req.session.user.id, user_name: req.session.user.name, user_email: req.session.user.email,
    product_id: product.id, product_name: product.name, category_id: product.category_id || null, price: Number(product.price || 0),
    status: 'awaiting_payment', payment_status: 'unpaid', payment_proof: '', created_at: new Date().toISOString()
  };
  data.orders.push(order); fs.writeFileSync(adminFile, JSON.stringify(data, null, 2));
  res.redirect('/buy/' + order.id);
});

router.get('/orders', requireLogin, function(req, res) {
  var file = path.join(__dirname, '..', 'data', 'admin-data.json');
  var data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) { data = {orders:[]}; }
  var orders = Array.isArray(data.orders) ? data.orders.filter(function(o) {
    return String(o.user_id) === String(req.session.user.id);
  }).sort(function(a,b) {
    return new Date(b.created_at || 0) - new Date(a.created_at || 0);
  }) : [];
  res.render('orders', {page:'My Orders', menuId:'orders', orders:orders, user:req.session.user});
});

router.get('/orders/:id', requireLogin, function(req, res) {
  var file = path.join(__dirname, '..', 'data', 'admin-data.json'); var data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) { data = {orders:[]}; }
  var order = (data.orders || []).find(function(o) {
    return String(o.id) === String(req.params.id) && o.user_id === req.session.user.id;
  });
  if (!order) return res.status(404).render('error', {status:404, message:'Order not found'});
  res.render('order', {page:'My Order', menuId:'orders', order:order, user:req.session.user});
});

router.get('/buy/:id', requireLogin, function(req,res){
  var file = path.join(__dirname, '..', 'data', 'admin-data.json'); var data;
  try { data = JSON.parse(fs.readFileSync(file,'utf8')); } catch(e) { data={orders:[],settings:{}}; }
  var order=(data.orders||[]).find(function(o){ return String(o.id)===String(req.params.id) && o.user_id===req.session.user.id; });
  if(!order) return res.status(404).render('error',{status:404,message:'Order not found'});
  var qr=(data.settings||{}).upi_qr || '';
  res.render('payment',{page:'Payment',menuId:'buy',order:order,upiQr:qr,error:null});
});

router.post('/buy/:id/payment', requireLogin, paymentUpload.single('payment_proof'), async function(req,res){
  var file = path.join(__dirname, '..', 'data', 'admin-data.json'); var data;
  try { data=JSON.parse(fs.readFileSync(file,'utf8')); } catch(e) { data={orders:[],settings:{}}; }
  var order=(data.orders||[]).find(function(o){ return String(o.id)===String(req.params.id) && o.user_id===req.session.user.id; });
  if(!order) return res.status(404).render('error',{status:404,message:'Order not found'});
  if(!req.file) return res.redirect('/buy/'+order.id+'?error=proof');
  order.payment_proof='/uploads/'+req.file.filename; order.payment_status='submitted'; order.status='payment_review'; order.payment_submitted_at=new Date().toISOString();
  fs.writeFileSync(file,JSON.stringify(data,null,2));
  var settings = (data.settings || {});
  var paymentMessage = discordMessageTemplate(settings.discord_msg_payment || '💳 {{site_name}} payment proof submitted\n\nOrder ID: {{order_id}}\nProduct: {{product}}\nAmount: ₹{{amount}}\nStatus: Payment Review\n\nYour payment proof has been received and is now under review.', {site_name:settings.site_name || 'BilloreCloud', name:req.session.user.name, email:req.session.user.email, order_id:order.id, product:order.product_name, amount:Number(order.price || 0).toFixed(2), status:'Payment Review'});
  var discordResult = await sendDiscordDM(req.session.user.discord_id, paymentMessage, {title:'💳 Payment Proof Submitted', color:0xFEE75C, thumbnail:settings.site_logo, footer:settings.site_name || 'BilloreCloud'});
  if (!discordResult.sent) console.warn('[Discord] Payment proof DM not sent:', discordResult.reason, discordResult.status || '', discordResult.error || '');
  var serverNotice = await discordService.postNewOrder(order, settings);
  if (serverNotice.sent) {
    order.discord_new_order_channel_id = serverNotice.channelId || '';
    order.discord_new_order_message_id = serverNotice.messageId || '';
    try { fs.writeFileSync(file, JSON.stringify(data, null, 2)); } catch(e) {}
  } else console.warn('[Discord] New order server message not sent:', serverNotice.reason || serverNotice.status);
  res.redirect('/panel?payment=success');
});


/* Hosting panel integration: opens the panel configured by the admin. */
router.get('/hosting-panel', requireLogin, function(req, res) {
  var file = path.join(__dirname, '..', 'data', 'admin-data.json');
  var data = {};
  try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) {}
  var panelUrl = String((data.settings || {}).panel_url || '').trim();
  if (!panelUrl) return res.status(503).render('error', {status:503, message:'Hosting panel is not configured yet. Please contact support.'});
  if (!/^https?:\/\//i.test(panelUrl)) panelUrl = 'https://' + panelUrl;
  res.redirect(panelUrl);
});

/* Existing simple pages */
router.get('/about', function(req,res){ res.render('about',{page:'About',menuId:'about'}); });
router.get('/contact', function(req,res){
  var tickets = req.session.user ? ticketsData().filter(function(t){ return t.user_id === req.session.user.id; }).sort(function(a,b){ return new Date(b.created_at)-new Date(a.created_at); }) : [];
  res.render('contact',{page:'Support',menuId:'contact',tickets:tickets,error:null,success:String(req.query.created||'')==='1'});
});
router.post('/support/tickets', requireLogin, function(req,res){
  var subject = String(req.body.subject || '').trim();
  var message = String(req.body.message || '').trim();
  if (!subject || !message) {
    var mine = ticketsData().filter(function(t){ return t.user_id === req.session.user.id; });
    return res.status(400).render('contact',{page:'Support',menuId:'contact',tickets:mine,error:'Please enter a subject and message.',success:null});
  }
  var tickets = ticketsData();
  tickets.push({
    id: 'TKT-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2,6).toUpperCase(),
    user_id: req.session.user.id,
    user_name: req.session.user.name,
    user_email: req.session.user.email,
    subject: subject,
    message: message,
    status: 'open',
    replies: [],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  });
  saveTickets(tickets);
  res.redirect('/contact?created=1');
});

module.exports = router;
