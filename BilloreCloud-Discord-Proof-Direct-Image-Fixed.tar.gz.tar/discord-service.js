const fs = require('fs');
const path = require('path');

const DISCORD_API = 'https://discord.com/api/v10';

function token() { return String(process.env.DISCORD_BOT_TOKEN || '').trim(); }
function headers(extra) { return Object.assign({Authorization:'Bot '+token(), 'Content-Type':'application/json'}, extra || {}); }
function validId(id) { return /^\d{17,20}$/.test(String(id || '').trim()); }

async function api(pathname, options={}) {
  const opts = Object.assign({}, options);
  const h = headers(opts.headers || {});
  const res = await fetch(DISCORD_API + pathname, Object.assign({}, opts, {headers:h}));
  let body = null;
  try { body = await res.json(); } catch (_) {}
  return {ok:res.ok,status:res.status,body};
}

async function sendDM(userId, content, options={}) {
  if (!token() || !validId(userId)) return {sent:false,reason:'not_configured'};
  try {
    const dm = await api('/users/@me/channels', {method:'POST',body:JSON.stringify({recipient_id:String(userId)})});
    if (!dm.ok) return {sent:false,reason:'dm_channel',status:dm.status,error:dm.body};
    const embed = {title:String(options.title || 'BilloreCloud Notification'),description:String(content || '').slice(0,4096),color:Number(options.color || 0x2f81f7),timestamp:new Date().toISOString(),footer:{text:String(options.footer || 'BilloreCloud')}};
    if (options.thumbnail && /^https?:\/\//i.test(String(options.thumbnail))) embed.thumbnail={url:String(options.thumbnail)};
    const msg = await api('/channels/'+dm.body.id+'/messages',{method:'POST',body:JSON.stringify({embeds:[embed]})});
    return {sent:msg.ok,reason:msg.ok?'sent':'message_failed',status:msg.status,error:msg.ok?null:msg.body};
  } catch(e) { return {sent:false,reason:'network_error'}; }
}

function guildConfig() {
  return {
    guildId:String(process.env.DISCORD_GUILD_ID || '').trim(),
    newCategoryId:String(process.env.DISCORD_NEW_ORDERS_CATEGORY_ID || '').trim(),
    newChannelId:String(process.env.DISCORD_NEW_ORDERS_CHANNEL_ID || '').trim(),
    completeCategoryId:String(process.env.DISCORD_COMPLETE_ORDERS_CATEGORY_ID || '').trim(),
    completeChannelId:String(process.env.DISCORD_COMPLETE_ORDERS_CHANNEL_ID || '').trim()
  };
}

async function sendChannelMessage(channelId, payload, filePath) {
  if (!token() || !validId(channelId)) return {sent:false,reason:'channel_not_configured'};
  try {
    if (filePath && fs.existsSync(filePath)) {
      const form = new FormData();
      form.append('payload_json', JSON.stringify(payload));
      const bytes = fs.readFileSync(filePath);
      form.append('files[0]', new Blob([bytes]), path.basename(filePath));
      const res = await fetch(DISCORD_API+'/channels/'+channelId+'/messages',{method:'POST',headers:{Authorization:'Bot '+token()},body:form});
      let body=null; try {body=await res.json();}catch(_){}
      return {sent:res.ok,status:res.status,message:body};
    }
    const res = await api('/channels/'+channelId+'/messages',{method:'POST',body:JSON.stringify(payload)});
    return {sent:res.ok,status:res.status,message:res.body};
  } catch(e) { return {sent:false,reason:'network_error'}; }
}

async function editChannelMessage(channelId,messageId,payload) {
  if (!token() || !validId(channelId) || !validId(messageId)) return {ok:false,reason:'not_configured'};
  return api('/channels/'+channelId+'/messages/'+messageId,{method:'PATCH',body:JSON.stringify(payload)});
}

async function createGuildStructure() {
  if (!token()) return {ok:false,reason:'bot_token_missing'};
  const cfg=guildConfig();
  if (!cfg.guildId || !validId(cfg.guildId)) return {ok:false,reason:'DISCORD_GUILD_ID_missing'};
  const guild=await api('/guilds/'+cfg.guildId,{method:'GET'});
  if(!guild.ok) return {ok:false,reason:'guild_access',status:guild.status};
  const channels=await api('/guilds/'+cfg.guildId+'/channels',{method:'GET'});
  if(!channels.ok) return {ok:false,reason:'channels_access',status:channels.status};
  let all=Array.isArray(channels.body)?channels.body:[];
  async function ensureCategory(name, configuredId){
    let c=all.find(x=>x.type===4 && (x.id===configuredId || x.name.toLowerCase()===name.toLowerCase()));
    if(c) return c;
    const r=await api('/guilds/'+cfg.guildId+'/channels',{method:'POST',body:JSON.stringify({name,type:4})});
    if(r.ok){all.push(r.body);return r.body;} return null;
  }
  async function ensureText(name,parent){
    let c=all.find(x=>x.type===0 && x.parent_id===parent && x.name.toLowerCase()===name.toLowerCase());
    if(c) return c;
    const r=await api('/guilds/'+cfg.guildId+'/channels',{method:'POST',body:JSON.stringify({name,type:0,parent_id:parent})});
    if(r.ok){all.push(r.body);return r.body;} return null;
  }
  const newCat=await ensureCategory('🆕 New Orders',cfg.newCategoryId);
  const completeCat=await ensureCategory('✅ Complete Orders',cfg.completeCategoryId);
  const newCh=newCat?await ensureText('new-orders',newCat.id):null;
  const completeCh=completeCat?await ensureText('completed-orders',completeCat.id):null;
  return {ok:!!(newCh&&completeCh),newCategory:newCat,newChannel:newCh,completeCategory:completeCat,completeChannel:completeCh};
}

async function postNewOrder(order, settings) {
  const structure=await createGuildStructure();
  if(!structure.ok) return {sent:false,reason:structure.reason || 'guild_structure'};
  const proofPath=order.payment_proof && order.payment_proof.startsWith('/uploads/') ? path.join(__dirname,'public',order.payment_proof.replace(/^\//,'')) : '';
  const embed={title:'🆕 New Order — Payment Proof',description:`**Order ID:** \`${order.id}\`\n**Client:** ${order.user_name || 'Unknown'}\n**Email:** ${order.user_email || '—'}\n**Product:** ${order.product_name || '—'}\n**Amount:** ₹${Number(order.price||0).toFixed(2)}\n**Status:** Payment Review`,color:0xFEE75C,timestamp:new Date().toISOString(),footer:{text:settings.site_name || 'BilloreCloud'}};
  if(proofPath && fs.existsSync(proofPath)) embed.image={url:'attachment://'+path.basename(proofPath)};
  const payload={embeds:[embed],components:[{type:1,components:[{type:2,style:3,label:'Accept',custom_id:'bc_order_accept:'+order.id},{type:2,style:4,label:'Reject',custom_id:'bc_order_reject:'+order.id},{type:2,style:1,label:'Complete Order',custom_id:'bc_order_complete:'+order.id,disabled:true}]}]};
  const sent=await sendChannelMessage(structure.newChannel.id,payload,proofPath);
  if(sent.sent) return {sent:true,channelId:structure.newChannel.id,messageId:sent.message && sent.message.id,structure};
  return sent;
}

async function postCompleteOrder(order, settings) {
  const structure=await createGuildStructure();
  if(!structure.ok) return {sent:false,reason:structure.reason || 'guild_structure'};
  const proofPath=order.payment_proof && order.payment_proof.startsWith('/uploads/') ? path.join(__dirname,'public',order.payment_proof.replace(/^\//,'')) : '';
  const embed={title:'✅ Order Completed',description:`**Order ID:** \`${order.id}\`\n**Client:** ${order.user_name || 'Unknown'}\n**Email:** ${order.user_email || '—'}\n**Product:** ${order.product_name || '—'}\n**Amount:** ₹${Number(order.price||0).toFixed(2)}\n**Status:** Completed`,color:0x57F287,timestamp:new Date().toISOString(),footer:{text:settings.site_name || 'BilloreCloud'}};
  if(proofPath && fs.existsSync(proofPath)) embed.image={url:'attachment://'+path.basename(proofPath)};
  return sendChannelMessage(structure.completeChannel.id,{embeds:[embed]},proofPath);
}

module.exports={sendDM,createGuildStructure,postNewOrder,postCompleteOrder,editChannelMessage,guildConfig};
